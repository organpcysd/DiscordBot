package com.sedmelluq.discord.lavaplayer.track;

/**
 * Marker interface for all loadable items
 */
public interface AudioItem {
}

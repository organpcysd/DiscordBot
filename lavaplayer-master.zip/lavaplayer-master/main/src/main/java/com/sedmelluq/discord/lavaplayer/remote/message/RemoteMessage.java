package com.sedmelluq.discord.lavaplayer.remote.message;

/**
 * A marker interface for all remote message classes.
 */
public interface RemoteMessage {
}

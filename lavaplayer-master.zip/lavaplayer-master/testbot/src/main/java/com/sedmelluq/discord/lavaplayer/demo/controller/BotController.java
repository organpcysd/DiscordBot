package com.sedmelluq.discord.lavaplayer.demo.controller;

public interface BotController {
}
